<form id="qodef-membership-reset-password-modal-part" class="qodef-m" method="POST">
	<div class="qodef-m-fields">
		<label><?php esc_html_e( 'Lost your password? Please enter your username or email address. You will receive a link to create a new password via email.', 'corsen-membership' ); ?></label>
		<input type="text" class="qodef-m-user-login" name="user_login" placeholder="<?php esc_attr_e( 'User name or email', 'corsen-membership' ); ?>" value="" required/>
	</div>
	<div class="qodef-m-action">
		<?php
		$reset_button_params = array(
			'custom_class' => 'qodef-m-action-button',
			'html_type'    => 'submit',
			'text'         => esc_html__( 'Reset Password', 'corsen-membership' ),
		);

		echo CorsenCore_Button_Shortcode::call_shortcode( $reset_button_params );

		corsen_membership_template_part( 'login-modal', 'templates/parts/spinner' );
		?>
	</div>
    <div class="qodef-m-action qodef-m-login">
        <?php
        $login_button_params = array(
            'custom_class'  => 'qodef-m-links-login',
            'button_layout' => 'textual',
            'link'          => '#',
            'text'          => esc_html__( 'Login', 'corsen-membership' ),
        );

        echo CorsenCore_Button_Shortcode::call_shortcode( $login_button_params );
        ?>
    </div>
	<?php corsen_membership_template_part( 'login-modal', 'templates/parts/response' ); ?>
	<?php corsen_membership_template_part( 'login-modal', 'templates/parts/hidden-fields', '', array( 'response_type' => 'reset-password' ) ); ?>
</form>
