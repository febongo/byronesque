<?php

include_once CORSEN_MEMBERSHIP_LOGIN_MODAL_PATH . '/helper.php';

foreach ( glob( CORSEN_MEMBERSHIP_LOGIN_MODAL_PATH . '/*/include.php' ) as $module ) {
	include_once $module;
}
