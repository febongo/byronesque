<?php

foreach ( glob( CORSEN_MEMBERSHIP_INC_PATH . '/general/dashboard/admin/*.php' ) as $module ) {
	include_once $module;
}

require_once CORSEN_MEMBERSHIP_INC_PATH . '/general/class-corsenmembership-page-templates.php';
include_once CORSEN_MEMBERSHIP_INC_PATH . '/general/helper.php';
