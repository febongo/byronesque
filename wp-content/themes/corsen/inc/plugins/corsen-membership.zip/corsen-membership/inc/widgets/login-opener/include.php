<?php

include_once CORSEN_MEMBERSHIP_INC_PATH . '/widgets/login-opener/class-corsenmembership-login-opener-widget.php';
