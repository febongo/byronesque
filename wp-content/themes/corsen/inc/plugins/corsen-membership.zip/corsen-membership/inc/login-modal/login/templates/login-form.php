<form id="qodef-membership-login-modal-part" class="qodef-m" method="GET">
	<div class="qodef-m-fields">
		<input type="text" class="qodef-m-user-name" name="user_name" placeholder="<?php esc_attr_e( 'User Name *', 'corsen-membership' ); ?>" value="" required pattern=".{3,}" autocomplete="username"/>
		<input type="password" class="qodef-m-user-password" name="user_password" placeholder="<?php esc_attr_e( 'Password *', 'corsen-membership' ); ?>" required autocomplete="current-password"/>
	</div>
	<div class="qodef-m-links">
		<div class="qodef-m-links-remember-me">
			<input type="checkbox" id="qodef-m-links-remember" class="qodef-m-links-remember" name="remember" value="forever"/>
			<label for="qodef-m-links-remember" class="qodef-m-links-remember-label"><?php esc_html_e( 'Remember me', 'corsen-membership' ); ?></label>
		</div>
		<?php
		$reset_button_params = array(
			'custom_class'  => 'qodef-m-links-reset-password',
			'button_layout' => 'textual',
			'link'          => '#',
			'text'          => esc_html__( 'Forgot password?', 'corsen-membership' ),
		);

		echo CorsenCore_Button_Shortcode::call_shortcode( $reset_button_params );
		?>
	</div>
	<div class="qodef-m-action">
		<?php
		$login_button_params = array(
			'custom_class' => 'qodef-m-action-button',
			'html_type'    => 'submit',
			'text'         => esc_html__( 'Login', 'corsen-membership' ),
		);

		echo CorsenCore_Button_Shortcode::call_shortcode( $login_button_params );

		corsen_membership_template_part( 'login-modal', 'templates/parts/spinner' );
		?>
	</div>
    <div class="qodef-m-action qodef-m-register">
        <?php
        $register_button_params = array(
            'custom_class'  => 'qodef-m-links-register',
            'button_layout' => 'textual',
            'link'          => '#',
            'text'          => esc_html__( 'Register', 'corsen-membership' ),
        );

        echo CorsenCore_Button_Shortcode::call_shortcode( $register_button_params );
        ?>
    </div>
	<?php
	/**
	 * Hook to include additional form content
	 */
	do_action( 'corsen_membership_action_login_form_template' );

	corsen_membership_template_part( 'login-modal', 'templates/parts/response' );
	corsen_membership_template_part( 'login-modal', 'templates/parts/hidden-fields', '', array( 'response_type' => 'login' ) );
	?>
</form>
