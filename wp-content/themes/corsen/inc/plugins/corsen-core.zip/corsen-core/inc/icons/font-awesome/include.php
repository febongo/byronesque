<?php

include_once CORSEN_CORE_INC_PATH . '/icons/font-awesome/class-corsencore-font-awesome-pack.php';
