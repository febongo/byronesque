<?php

include_once CORSEN_CORE_INC_PATH . '/core-dashboard/sub-pages/system-info/class-corsencore-dashboard-system-info-page.php';
