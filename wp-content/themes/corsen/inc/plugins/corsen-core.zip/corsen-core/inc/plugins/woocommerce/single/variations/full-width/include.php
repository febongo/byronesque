<?php

include_once CORSEN_CORE_PLUGINS_PATH . '/woocommerce/single/variations/full-width/full-width.php';
