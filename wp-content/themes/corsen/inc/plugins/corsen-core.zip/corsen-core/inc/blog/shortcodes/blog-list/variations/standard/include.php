<?php

include_once CORSEN_CORE_INC_PATH . '/blog/shortcodes/blog-list/variations/standard/standard.php';
