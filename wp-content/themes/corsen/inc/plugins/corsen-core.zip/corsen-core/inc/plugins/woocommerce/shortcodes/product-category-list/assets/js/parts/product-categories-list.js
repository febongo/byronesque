(function ( $ ) {
	'use strict';

	qodefCore.shortcodes.corsen_core_product_category_list                    = {};
	qodefCore.shortcodes.corsen_core_product_category_list.qodefMasonryLayout = qodef.qodefMasonryLayout;
	qodefCore.shortcodes.corsen_core_product_category_list.qodefSwiper        = qodef.qodefSwiper;
	qodefCore.shortcodes.corsen_core_product_category_list.qodefAppear        = qodefCore.qodefAppear;

})( jQuery );
