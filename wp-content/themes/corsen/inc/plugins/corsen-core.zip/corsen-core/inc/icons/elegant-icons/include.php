<?php

include_once CORSEN_CORE_INC_PATH . '/icons/elegant-icons/class-corsencore-elegant-icons-pack.php';
