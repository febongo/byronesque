<?php

include_once CORSEN_CORE_PLUGINS_PATH . '/woocommerce/shortcodes/product-list/variations/boxed-below/boxed-below.php';
