<?php

include_once CORSEN_CORE_PLUGINS_PATH . '/woocommerce/single/variations/big-images/big-images.php';
