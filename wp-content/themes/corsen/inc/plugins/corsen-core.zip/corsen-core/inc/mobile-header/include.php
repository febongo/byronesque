<?php

include_once CORSEN_CORE_INC_PATH . '/mobile-header/helper.php';
include_once CORSEN_CORE_INC_PATH . '/mobile-header/class-corsencore-mobile-header.php';
include_once CORSEN_CORE_INC_PATH . '/mobile-header/class-corsencore-mobile-headers.php';
include_once CORSEN_CORE_INC_PATH . '/mobile-header/template-functions.php';
