<?php

include_once CORSEN_CORE_PLUGINS_PATH . '/twitter/shortcodes/twitter-list/widget/class-corsencore-twitter-list-widget.php';
