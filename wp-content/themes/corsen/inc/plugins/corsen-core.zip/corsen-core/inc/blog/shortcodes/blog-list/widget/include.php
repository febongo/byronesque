<?php

include_once CORSEN_CORE_INC_PATH . '/blog/shortcodes/blog-list/widget/class-corsencore-blog-list-widget.php';
include_once CORSEN_CORE_INC_PATH . '/blog/shortcodes/blog-list/widget/class-corsencore-simple-blog-list-widget.php';
