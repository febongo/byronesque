<?php

include_once CORSEN_CORE_PLUGINS_PATH . '/woocommerce/shortcodes/product-list-indent-slider/variations/boxed-below/boxed-below.php';
