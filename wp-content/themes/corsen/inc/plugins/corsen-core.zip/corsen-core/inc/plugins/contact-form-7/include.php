<?php

include_once CORSEN_CORE_PLUGINS_PATH . '/contact-form-7/class-corsencore-contact-form-7.php';
