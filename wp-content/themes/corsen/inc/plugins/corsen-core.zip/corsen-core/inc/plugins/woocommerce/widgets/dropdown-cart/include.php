<?php

include_once CORSEN_CORE_PLUGINS_PATH . '/woocommerce/widgets/dropdown-cart/class-corsencore-woocommerce-dropdown-cart-widget.php';
