<?php

include_once CORSEN_CORE_PLUGINS_PATH . '/woocommerce/widgets/side-area-cart/class-corsencore-woocommerce-side-area-cart-widget.php';
