<?php

include_once CORSEN_CORE_INC_PATH . '/header/layouts/centered/helper.php';
include_once CORSEN_CORE_INC_PATH . '/header/layouts/centered/class-corsencore-centered-header.php';
include_once CORSEN_CORE_INC_PATH . '/header/layouts/centered/dashboard/admin/centered-header-options.php';
include_once CORSEN_CORE_INC_PATH . '/header/layouts/centered/dashboard/meta-box/centered-header-meta-box.php';
