<?php

include_once CORSEN_CORE_PLUGINS_PATH . '/twitter/shortcodes/twitter-list/class-corsencore-twitter-list-shortcode.php';
