<?php

include_once CORSEN_CORE_PLUGINS_PATH . '/instagram/shortcodes/instagram-list/helper.php';
include_once CORSEN_CORE_PLUGINS_PATH . '/instagram/shortcodes/instagram-list/class-corsencore-instagram-list-shortcode.php';
