(function ($) {

    $(document).on("click","#bn-search .fa-search",function() {
        $(".bn-search-form").addClass('bn-show')
    });

    $(document).on("click","#bn-search-close",function() {
        console.log("close");
        $(".bn-search-form").removeClass('bn-show')
    });

    $(document).on("keyup","#bn-search-value", function() {
        var query = $(this).val();
        productSearch(query);
    })



    function productSearch(query){

        query = query.trim();

        if (query.length >= 3) {

            $.ajax({
                url:opt.ajaxUrl,
                type: 'post',
                data: { action: 'search_product', keyword: query },
                success: function(data) {

                    console.log(data)
                }
            });

        } else {

            console.log("else")

        }
    }


})(jQuery);