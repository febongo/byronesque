<?php
/*
Plugin Name: Byronesque Shop Functions
Description: Byronesque custom functions such as searching and mini cart functions
Author: Felix Bongo (febongo@gmail.com)
Version: 1.0
*/

// register jquery and style on initialization
add_action('init', 'register_script');
function register_script() {
    wp_register_script( 'bn_scripts', plugins_url('/assets/scripts.js', __FILE__), array('jquery'), '3.3.2' );
    wp_localize_script(
        'bn_scripts',
        'opt',
        array(
            'ajaxUrl'   => admin_url('admin-ajax.php'),
            'noResults' => esc_html__( 'No products found', 'textdomain' ),
            )
        );
        
    wp_register_style( 'bn_styles', plugins_url('/assets/styles.css', __FILE__), false, '1.0.0', 'all');
}

// use the registered jquery and style above
add_action('wp_enqueue_scripts', 'enqueue_style');

function enqueue_style(){
    wp_enqueue_script('bn_scripts');
    
    wp_enqueue_style( 'bn_styles' );
}
        
include('postTypes/post_types.php');
include('widgets/search.php');
    
?>