<?php 

// Creating the widget
class wpb_widget extends WP_Widget {
 
    function __construct() {
        parent::__construct(
        
        // Base ID of your widget
        'wpb_widget', 
        
        // Widget name will appear in UI
        __('Byronesque Search', 'wpb_widget_domain'), 
        
        // Widget description
        array( 'description' => __( 'Realtime product search', 'wpb_widget_domain' ), )
        );
    }
     
    // Creating widget front-end
     
    public function widget( $args, $instance ) {
        $title = apply_filters( 'widget_title', $instance['title'] );
        
        // before and after widget arguments are defined by themes
        echo $args['before_widget'];
        // if ( ! empty( $title ) )
        // echo $args['before_title'] . $title . $args['after_title'];
        
        // This is where you run the code and display the output
        //echo __( 'Search Area Here', 'wpb_widget_domain' );
        ?>
            <div id="bn-search" class="search-area">
                <i class="fa fa-search"></i>
                <div id="bn-search-wrap" class="bn-search-form">
                    <input id="bn-search-value" type="text" placeholder="Search Products" value="">
                    <span id="bn-search-close"><i class="fa fa-close"></i></span>
                </div>
            </div>
        <?php
        // END FRONT END DISPLAY
        echo $args['after_widget'];
    }
     
    // Widget Backend
    public function form( $instance ) {
        if ( isset( $instance[ 'title' ] ) ) {
            $title = $instance[ 'title' ];
        } else {
            $title = __( 'New title', 'wpb_widget_domain' );
        }
        // Widget admin form
        ?>
        <p>Byronesque Search Function</p>
        <?php
    }
     
    // Updating widget replacing old instances with new
    public function update( $new_instance, $old_instance ) {
        $instance = array();
        $instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
        return $instance;
    }
     
    // Class wpb_widget ends here
} 
     
// Register and load the widget
function wpb_load_widget() {
    register_widget( 'wpb_widget' );
}
add_action( 'widgets_init', 'wpb_load_widget' );


/*  Search action
/*-------------------*/

function search_product() {

    global $wpdb, $woocommerce;

    if (isset($_POST['keyword']) && !empty($_POST['keyword'])) {

        $keyword = $_POST['keyword'];

        if (isset($_POST['category']) && !empty($_POST['category'])) {

            $category = $_POST['category'];

            $querystr = "SELECT DISTINCT * FROM $wpdb->posts AS p
            LEFT JOIN $wpdb->term_relationships AS r ON (p.ID = r.object_id)
            INNER JOIN $wpdb->term_taxonomy AS x ON (r.term_taxonomy_id = x.term_taxonomy_id)
            INNER JOIN $wpdb->terms AS t ON (r.term_taxonomy_id = t.term_id)
            WHERE p.post_type IN ('product')
            AND p.post_status = 'publish'
            AND x.taxonomy = 'product_cat'
            AND (
                (x.term_id = {$category})
                OR
                (x.parent = {$category})
            )
            AND (
                (p.ID IN (SELECT post_id FROM $wpdb->postmeta WHERE meta_key = '_sku' AND meta_value LIKE '%{$keyword}%'))
                OR
                (p.post_content LIKE '%{$keyword}%')
                OR
                (p.post_title LIKE '%{$keyword}%')
            )
            ORDER BY t.name ASC, p.post_date DESC;";

        } else {
            $querystr = "SELECT DISTINCT $wpdb->posts.*
            FROM $wpdb->posts, $wpdb->postmeta
            WHERE $wpdb->posts.ID = $wpdb->postmeta.post_id
            AND (
                ($wpdb->postmeta.meta_key = '_sku' AND $wpdb->postmeta.meta_value LIKE '%{$keyword}%')
                OR
                ($wpdb->posts.post_content LIKE '%{$keyword}%')
                OR
                ($wpdb->posts.post_title LIKE '%{$keyword}%')
            )
            AND $wpdb->posts.post_status = 'publish'
            AND $wpdb->posts.post_type = 'product'
            ORDER BY $wpdb->posts.post_date DESC";
        }

        $query_results = $wpdb->get_results($querystr);

        if (!empty($query_results)) {

            $output = '';

            foreach ($query_results as $result) {

                $price      = get_post_meta($result->ID,'_regular_price');
                $price_sale = get_post_meta($result->ID,'_sale_price');
                $currency   = get_woocommerce_currency_symbol();

                // $sku   = get_post_meta($result->ID,'_sku');
                // $stock = get_post_meta($result->ID,'_stock_status');

                $categories = wp_get_post_terms($result->ID, 'product_cat');

                $output .= '<li>';
                    $output .= '<a href="'.get_post_permalink($result->ID).'">';
                        $output .= '<div class="product-image">';
                            $output .= '<img src="'.esc_url(get_the_post_thumbnail_url($result->ID,'thumbnail')).'">';
                        $output .= '</div>';
                        $output .= '<div class="product-data">';
                            $output .= '<h3>'.$result->post_title.'</h3>';
                            $output .= '<h4>'.$result->post_content.'</h4>';
                            if (!empty($price)) {
                                $output .= '<div class="product-price">';
                                    $output .= '<span class="regular-price">'.$price[0].'</span>';
                                    if (!empty($price_sale)) {
                                        $output .= '<span class="sale-price">'.$price_sale[0].'</span>';
                                    }
                                    $output .= $currency;
                                $output .= '</div>';
                            }
                            if (!empty($categories)) {
                                $output .= '<div class="product-categories">';
                                    foreach ($categories as $category) {
                                        if ($category->parent) {
                                            $parent = get_term_by('id',$category->parent,'product_cat');
                                            $output .= '<span>'.$parent->name.'</span>';
                                        }
                                        $output .= '<span>'.$category->name.'</span>';
                                    }
                                $output .= '</div>';
                            }
                            // if (!empty($sku)) {
                            //     $output .= '<div class="product-sku">'.esc_html__( 'SKU:', 'textdomain' ).' '.$sku[0].'</div>';
                            // }

                            // if (!empty($stock)) {
                            //     $output .= '<div class="product-stock">'.$stock[0].'</div>';
                            // }

                        $output .= '</div>';
                        $output .= '</a>';
                $output .= '</li>';
            }

            if (!empty($output)) {
                echo $output;
            }
        }
    }

    die();
}
add_action( 'wp_ajax_search_product', 'search_product' );
add_action( 'wp_ajax_nopriv_search_product', 'search_product' );
